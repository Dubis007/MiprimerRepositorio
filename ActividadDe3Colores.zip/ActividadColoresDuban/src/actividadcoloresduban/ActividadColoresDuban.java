package actividadcoloresduban;

public class ActividadColoresDuban {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        String[][] simpsons = {
    {"Homero", "Bart", "Maggie", "Marge", "Lisa"},
    {"NedF", "RodF", "ToddF", "MaudeF", "PazF"},
    {"BobPat", "Apu", "MrBurns", "Moe", "Smitters"},
    {"Barny", "MilH", "EdnaK", "Nelson", "AbrahamS"},
    {"Lenny", "Carl", "Clancy", "Krusty", "Willie"}
};

       
         for (int i = 0; i < simpsons.length; i++) { // filas
            for (int j = 0; j < simpsons[0].length; j++) { // columnas
                System.out.print(simpsons[i][j] + "\t");
            }
            System.out.println();
            
        }
    }
    
}
