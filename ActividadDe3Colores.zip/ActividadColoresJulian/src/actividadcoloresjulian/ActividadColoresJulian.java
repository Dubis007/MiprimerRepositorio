package actividadcoloresjulian;

public class ActividadColoresJulian {

    public static void main(String[] args) {
        
         String[][] Perros = {
    {"Chihuahua", "Pomerania", "Salchicha", "Doberman", "Bulldog"},
    {"Yorkshire", "Beagle", "Pastor", "Golden", "Carlino"},
    {"Galgo", "Husky", "Dalmata", "Shibainu","Sharpei" },
    {"Labrador","Pinscher","Rottweiler" ,"Bobtail" ,"Pug"},
    {"Cocker", "Boxer", "Caniche", "Poodle", "Pitbull"}
    };
         
         for (int i = 0; i < Perros.length; i++) { // filas
            for (int j = 0; j < Perros[0].length; j++) { // columnas
                System.out.print(Perros[i][j] + "\t");
            }
            System.out.println();
         }
    }
}
