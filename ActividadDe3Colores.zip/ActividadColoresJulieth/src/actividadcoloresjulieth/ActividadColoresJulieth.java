
package actividadcoloresjulieth;

public class ActividadColoresJulieth {

    public static void main(String[] args) {
        
         String[][] LooneyToons = {
    {"Bugs", "Lucas", "Porki", "Elmert", "Silvreste"},
    {"Piolin", "Sam", "Speedy", "Coyote", "Correcaminos"},
    {"Taz", "Marvin", "Pepe", "Claudio","Gossamer" },
    {"Hector","Charlie","Lola" ,"Michigan" ,"Barnyard"},
    {"Abuela", "Bruja", "Clyde", "Sniffles", "Chupacabras"}
    };
         
         for (int i = 0; i < LooneyToons.length; i++) { // filas
            for (int j = 0; j < LooneyToons[0].length; j++) { // columnas
                System.out.print(LooneyToons[i][j] + "\t");
            }
            System.out.println();
         }
    }
}
