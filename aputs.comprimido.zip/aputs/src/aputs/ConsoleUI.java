package aputs;

import java.util.List;
import java.util.Scanner;

public class ConsoleUI {
 private Repository repo;
    private Scanner sc = new Scanner(System.in);

    public ConsoleUI(Repository repo) {
        this.repo = repo;
    }

    public void start() {
        System.out.println("=== APUTS UTS (Prototipo) ===");
        // Mostrar FAQ/intro breve
        mostrarFAQBreve();

        while (true) {
            System.out.println("""
                    ===== MENÚ PRINCIPAL =====
                    1) Registrar usuario
                    2) Registrar lugar
                    3) Registrar APUTS
                    4) Ver historial completo
                    5) Exportar datos de un usuario (.txt)
                    6) Ver perfil
                    7) Filtrar lugares
                    8) Restablecer contraseña
                    9) FAQ completa
                    10) Mostrar gráfica ASCII (usuario)
                    0) Salir
                    """);
            String op = sc.nextLine();
            switch (op) {
                case "1" -> registrarUsuario();
                case "2" -> registrarLugar();
                case "3" -> registrarAputs();
                case "4" -> mostrarHistorial();
                case "5" -> exportar();
                case "6" -> verPerfil();
                case "7" -> menuFiltros();
                case "8" -> restablecerContrasena();
                case "9" -> mostrarFAQCompleta();
                case "10" -> mostrarGraficaUsuario();
                case "0" -> {
                    System.out.println("Saliendo. Datos guardados.");
                    return;
                }
                default -> System.out.println("Opción no válida.");
            }
        }
    }

    private void mostrarFAQBreve() {
        System.out.println("Bienvenido a APUTS UTS. Usa la opción 9 para ver las FAQ completas.");
    }

    // -------------------------
    // Registrar usuario
    // -------------------------
    private void registrarUsuario() {
    System.out.print("Nombre: ");
    String nombre = sc.nextLine().trim();
    if (nombre.isEmpty()) { System.out.println("Nombre obligatorio."); return; }

    System.out.print("Correo: ");
    String correo = sc.nextLine().trim();
    if (correo.isEmpty()) { System.out.println("Correo obligatorio."); return; }
    if (repo.correoExiste(correo)) { System.out.println("Error: correo ya registrado."); return; }

    System.out.print("Contraseña: ");
    String pass = sc.nextLine().trim();
    if (pass.isEmpty()) { System.out.println("Contraseña obligatoria."); return; }

    Usuario u = new Usuario(nombre, correo, pass);

    // =========================================
    // NUEVOS AVATARES ASCII SEGUROS
    // =========================================
    System.out.println("""
        Elige avatar:
        (1) ( ^ _ ^ )
        (2) ( - _ - )
        (3) ( > _ < )
        (4) ( ^ o ^ )
        (5) ( n _ n )
        Ingrese número:
        """);

String av = sc.nextLine().trim();

switch (av) {
    case "1" -> u.setAvatar("( ^ _ ^ )");
    case "2" -> u.setAvatar("( - _ - )");
    case "3" -> u.setAvatar("( > _ < )");
    case "4" -> u.setAvatar("( ^ o ^ )");
    case "5" -> u.setAvatar("( n _ n )");
    default -> u.setAvatar("( ^ _ ^ )");
}
    repo.addUsuario(u);
    System.out.println("Usuario creado con ID: " + u.getId());
}

    // -------------------------
    // Registrar lugar
    // -------------------------
    private void registrarLugar() {
        System.out.print("Nombre del lugar: ");
        String nombre = sc.nextLine().trim();
        if (nombre.isEmpty()) { System.out.println("Nombre obligatorio."); return; }
        if (repo.lugarExistePorNombre(nombre)) { System.out.println("Ya existe un lugar con ese nombre."); return; }

        System.out.print("Categoría: ");
        String categoria = sc.nextLine().trim();
        if (categoria.isEmpty()) { System.out.println("Categoría obligatoria."); return; }

        System.out.print("Descripción: ");
        String descripcion = sc.nextLine().trim();
        if (descripcion.isEmpty()) descripcion = "-";

        LugarAPUTS l = new LugarAPUTS(nombre, categoria, descripcion);
        repo.addLugar(l);
        System.out.println("Lugar creado con ID: " + l.getId());
    }

    // -------------------------
    // Registrar APUTS
    // -------------------------
    private void registrarAputs() {
        try {
            System.out.print("ID del usuario: ");
            int idu = Integer.parseInt(sc.nextLine());
            Usuario user = repo.buscarUsuarioPorId(idu);
            if (user == null) { System.out.println("Usuario no encontrado."); return; }

            System.out.print("ID del lugar: ");
            int idl = Integer.parseInt(sc.nextLine());
            LugarAPUTS lugar = repo.buscarLugarPorId(idl);
            if (lugar == null) { System.out.println("Lugar no encontrado."); return; }

            System.out.print("Cantidad de APUTS (entero): ");
            int cantidad = Integer.parseInt(sc.nextLine());
            if (cantidad <= 0) { System.out.println("Cantidad debe ser positiva."); return; }

            TransaccionAPUTS t = new TransaccionAPUTS(idu, idl, cantidad);
            repo.addTransaccion(t);
            System.out.println("Transacción registrada. ID transacción: " + t.getId());
        } catch (NumberFormatException e) {
            System.out.println("ID o cantidad inválida (deben ser números).");
        }
    }

    // -------------------------
    // Historial (acciones)
    // -------------------------
    private void mostrarHistorial() {
        System.out.println("===== HISTORIAL DE ACCIONES =====");
        for (String h : repo.historialAcciones) {
            System.out.println(h);
        }
    }

    // -------------------------
    // Exportar
    // -------------------------
    private void exportar() {
        try {
            System.out.print("ID del usuario a exportar: ");
            int id = Integer.parseInt(sc.nextLine());
            repo.exportarDatosUsuario(id);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido.");
        }
    }

    // -------------------------
    // Perfil
    // -------------------------
    private void verPerfil() {
        try {
            System.out.print("ID del usuario: ");
            int id = Integer.parseInt(sc.nextLine());
            String resumen = repo.perfilResumen(id);
            System.out.println(resumen);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido.");
        }
    }

    // -------------------------
    // Filtros de lugares
    // -------------------------
    private void menuFiltros() {
        System.out.println("""
                ==== FILTROS DE LUGARES ====
                1) Por categoría
                2) Por nombre (contiene)
                3) Por popularidad (más visitados)
                0) Volver
                """);
        String op = sc.nextLine();
        switch (op) {
            case "1" -> {
                System.out.print("Ingrese categoría: ");
                String cat = sc.nextLine();
                List<LugarAPUTS> r = repo.filtrarLugaresPorCategoria(cat);
                mostrarListaLugares(r);
            }
            case "2" -> {
                System.out.print("Texto a buscar en nombre: ");
                String t = sc.nextLine();
                List<LugarAPUTS> r = repo.filtrarLugaresPorNombre(t);
                mostrarListaLugares(r);
            }
            case "3" -> {
                List<LugarAPUTS> r = repo.filtrarLugaresPorPopularidad();
                mostrarListaLugares(r);
            }
            default -> System.out.println("Volviendo al menú principal.");
        }
    }

    private void mostrarListaLugares(List<LugarAPUTS> lista) {
        if (lista == null || lista.isEmpty()) {
            System.out.println("No se encontraron lugares.");
            return;
        }
        System.out.println("ID | Nombre | Categoria | Descripción");
        for (LugarAPUTS l : lista) {
            System.out.println(l.getId() + " | " + l.getNombre() + " | " + l.getCategoria() + " | " + l.getDescripcion());
        }
    }

    // -------------------------
    // Restablecer contraseña
    // -------------------------
    private void restablecerContrasena() {
        System.out.print("Correo registrado: ");
        String correo = sc.nextLine();
        if (correo.isEmpty()) { System.out.println("Correo obligatorio."); return; }
        Usuario u = repo.buscarUsuarioPorCorreo(correo);
        if (u == null) { System.out.println("Correo no encontrado."); return; }

        System.out.print("Nueva contraseña: ");
        String nueva = sc.nextLine();
        if (nueva.isEmpty()) { System.out.println("Contraseña no puede estar vacía."); return; }

        boolean ok = repo.restablecerContrasena(correo, nueva);
        System.out.println(ok ? "Contraseña restablecida." : "Error al restablecer.");
    }

    // -------------------------
    // FAQ
    // -------------------------
    private void mostrarFAQCompleta() {
        System.out.println("=== FAQ APUTS UTS ===");
        System.out.println("Q: ¿Qué son las APUTS?");
        System.out.println("A: Actividades que suman puntos de participación académica/extracurricular.");
        System.out.println();
        System.out.println("Q: ¿Cuántas APUTS necesito para graduarme?");
        System.out.println("A: 96 APUTS (según reglamento UTS).");
        System.out.println();
        System.out.println("Q: ¿Cómo obtengo APUTS?");
        System.out.println("A: Registrándote en eventos institucionales como UTSmart, CIINATIC, Expo Bienestar, semilleros, talleres, etc.");
        System.out.println();
        System.out.println("Q: ¿Puedo exportar mis datos?");
        System.out.println("A: Sí, usa la opción 5 para crear un archivo .txt con tu reporte.");
        System.out.println();
    }

    // -------------------------
    // Gráfica ASCII para usuario
    // -------------------------
    private void mostrarGraficaUsuario() {
        try {
            System.out.print("ID del usuario: ");
            int id = Integer.parseInt(sc.nextLine());
            Usuario u = repo.buscarUsuarioPorId(id);
            if (u == null) { System.out.println("Usuario no encontrado."); return; }
            double pct = repo.porcentajeAvance(u);
            System.out.println("Gráfica APUTS acumuladas para " + u.getNombre() + ":");
            System.out.println(repo.asciiBar(pct));
            System.out.println("Total APUTS: " + u.getTotalAputs() + " / " + Repository.APUTS_REQUERIDAS);
            // mostrar alertas si corresponde
            repo.checkAndLogAlertas(u);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido.");
        }
    }
}
