package aputs;

public class IdGenerator {
    
     private static int nextId = 1;

    public static int generarId() {
        if (nextId >= 1_000_000) {
            throw new RuntimeException("Se alcanzó el límite máximo de IDs.");
        }
        return nextId++;
    }

    // método para setear inicio (si cargas desde archivo en el futuro)
    public static void setNextId(int v) {
        nextId = v;
    }
}
