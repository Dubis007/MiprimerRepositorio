package aputs;

import java.io.Serializable;

public class LugarAPUTS implements Serializable {
    private int id;
    private String nombre;
    private String categoria;
    private String descripcion;

    public LugarAPUTS(String nombre, String categoria, String descripcion) {
        this.id = IdGenerator.generarId();
        this.nombre = nombre;
        this.categoria = categoria;
        this.descripcion = descripcion;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCategoria() { return categoria; }
    public String getDescripcion() { return descripcion; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
