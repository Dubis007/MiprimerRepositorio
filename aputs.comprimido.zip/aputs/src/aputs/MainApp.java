package aputs;

public class MainApp {

    public static void main(String[] args) {
         Repository repo = new Repository();
        ConsoleUI ui = new ConsoleUI(repo);
        ui.start();
        System.out.println("Saliendo APUTS UTS. Datos guardados.");
    
    }
    
}
