package aputs;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;
import java.util.stream.Collectors;

public class Repository {
    
    public List<Usuario> usuarios = new ArrayList<>();
    public List<LugarAPUTS> lugares = new ArrayList<>();
    public List<TransaccionAPUTS> transacciones = new ArrayList<>();

    // Historial global de acciones
    public List<String> historialAcciones = new ArrayList<>();

    // Constantes
    public static final int APUTS_REQUERIDAS = 96;

    // ===========================
    // LOG
    // ===========================
    public void log(String mensaje) {
        String linea = String.format("[%s] %s", java.time.LocalDateTime.now(), mensaje);
        historialAcciones.add(linea);
        System.out.println(linea); // opcional: ver log en consola
    }

    // ===========================
    // VALIDACIONES
    // ===========================
    public boolean correoExiste(String correo) {
        return usuarios.stream().anyMatch(u -> u.getCorreo().equalsIgnoreCase(correo));
    }

    public boolean lugarExistePorNombre(String nombre) {
        return lugares.stream().anyMatch(l -> l.getNombre().equalsIgnoreCase(nombre));
    }

    // ===========================
    // CRUD y guardado (txt)
    // ===========================
    public void addUsuario(Usuario u) {
        usuarios.add(u);
        log("Usuario creado: " + u.getNombre() + " (ID " + u.getId() + ")");
        saveUsuarios();
    }

    public void addLugar(LugarAPUTS l) {
        lugares.add(l);
        log("Lugar creado: " + l.getNombre() + " (ID " + l.getId() + ")");
        saveLugares();
    }

    public void addTransaccion(TransaccionAPUTS t) {
        transacciones.add(t);
        log("Transacción: Usuario " + t.getIdUsuario() + " obtuvo +" + t.getCantidad()
                + " APUTS en Lugar " + t.getIdLugar() + " (ID transacción " + t.getId() + ")");
        // actualizar usuario
        Usuario u = buscarUsuarioPorId(t.getIdUsuario());
        if (u != null) {
            u.addAputs(t.getCantidad());
            // comprobar alertas y marcar si corresponde
            checkAndLogAlertas(u);
        }
        saveTransacciones();
        saveUsuarios();
    }

    private void saveUsuarios() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("usuarios.txt"))) {
            for (Usuario u : usuarios) {
                // guardar campos: id;nombre;correo;contrasena;avatar;totalAputs;hitosCsv
                String hitos = String.join(",", u.getHitosNotificados().stream().map(String::valueOf).collect(Collectors.toList()));
                pw.println(u.getId() + ";" + u.getNombre() + ";" + u.getCorreo() + ";" + u.getContrasena()
                        + ";" + u.getAvatar() + ";" + u.getTotalAputs() + ";" + hitos);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveLugares() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("lugares.txt"))) {
            for (LugarAPUTS l : lugares) {
                pw.println(l.getId() + ";" + l.getNombre() + ";" + l.getCategoria() + ";" + l.getDescripcion());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveTransacciones() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("transacciones.txt"))) {
            for (TransaccionAPUTS t : transacciones) {
                pw.println(t.getId() + ";" + t.getIdUsuario() + ";" + t.getIdLugar() + ";" + t.getCantidad() + ";" + t.getFecha());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ===========================
    // BÚSQUEDAS y UTILIDADES
    // ===========================
    public Usuario buscarUsuarioPorId(int id) {
        return usuarios.stream().filter(u -> u.getId() == id).findFirst().orElse(null);
    }

    public Usuario buscarUsuarioPorCorreo(String correo) {
        return usuarios.stream().filter(u -> u.getCorreo().equalsIgnoreCase(correo)).findFirst().orElse(null);
    }

    public LugarAPUTS buscarLugarPorId(int id) {
        return lugares.stream().filter(l -> l.getId() == id).findFirst().orElse(null);
    }

    // FILTROS de lugares
    public List<LugarAPUTS> filtrarLugaresPorCategoria(String categoria) {
        return lugares.stream().filter(l -> l.getCategoria().equalsIgnoreCase(categoria)).collect(Collectors.toList());
    }

    public List<LugarAPUTS> filtrarLugaresPorNombre(String texto) {
        return lugares.stream().filter(l -> l.getNombre().toLowerCase().contains(texto.toLowerCase())).collect(Collectors.toList());
    }

    // Popularidad: número de transacciones por lugar (descendente)
    public List<LugarAPUTS> filtrarLugaresPorPopularidad() {
        Map<Integer, Long> cont = transacciones.stream().collect(Collectors.groupingBy(TransaccionAPUTS::getIdLugar, Collectors.counting()));
        return lugares.stream()
                .sorted((a, b) -> Long.compare(cont.getOrDefault(b.getId(), 0L), cont.getOrDefault(a.getId(), 0L)))
                .collect(Collectors.toList());
    }

    // Porcentaje de avance de un usuario
    public double porcentajeAvance(Usuario u) {
        return Math.min(100.0, (u.getTotalAputs() * 100.0) / APUTS_REQUERIDAS);
    }

    // ASCII BAR para porcentaje (ancho 40)
    public String asciiBar(double porcentaje) {
        int ancho = 40;
        int llenos = (int) Math.round((porcentaje / 100.0) * ancho);
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < ancho; i++) sb.append(i < llenos ? "#" : " ");
        sb.append("] ");
        sb.append(String.format("%.1f%%", porcentaje));
        return sb.toString();
    }

    // ===========================
    // ALERTAS (50,75,90)
    // ===========================
    public void checkAndLogAlertas(Usuario u) {
        double pct = porcentajeAvance(u);
        int[] hitos = {50, 75, 90};
        for (int h : hitos) {
            if (pct >= h && !u.yaNotificado(h)) {
                String msg = "ALERTA: Usuario " + u.getNombre() + " (ID " + u.getId() + ") alcanzó " + h + "% de APUTS.";
                log(msg);
                u.marcarHitoNotificado(h);
            }
        }
    }

    // ===========================
    // EXPORTACION mejorada
    // ===========================
    public void exportarDatosUsuario(int idUsuario) {
        Usuario u = buscarUsuarioPorId(idUsuario);
        if (u == null) {
            System.out.println("Usuario no encontrado.");
            return;
        }

        String archivo = "usuario_" + idUsuario + "_reporte.txt";
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            pw.println("========= REPORTE DE USUARIO APUTS =========");
            pw.println("ID Usuario: " + u.getId());
            pw.println("Nombre: " + u.getNombre());
            pw.println("Correo: " + u.getCorreo());
            pw.println("Avatar: " + u.getAvatar());
            pw.println("Total APUTS: " + u.getTotalAputs());
            double pct = porcentajeAvance(u);
            pw.println("Porcentaje de avance: " + String.format("%.2f", pct) + "%");
            pw.println(asciiBar(pct));
            pw.println("--------------------------------------------");

            // alertas alcanzadas
            pw.println("Alertas alcanzadas: " + (u.getHitosNotificados().isEmpty() ? "Ninguna" :
                    u.getHitosNotificados().stream().sorted().map(String::valueOf).collect(Collectors.joining(", ")) + "%"));
            pw.println("--------------------------------------------");
            pw.println("Historial de transacciones:");
            pw.println();
            transacciones.stream().filter(t -> t.getIdUsuario() == idUsuario).forEach(t -> {
                LugarAPUTS lugar = buscarLugarPorId(t.getIdLugar());
                pw.println("Fecha: " + t.getFecha());
                pw.println("Lugar: " + (lugar != null ? lugar.getNombre() + " (ID " + lugar.getId() + ")" : "ID " + t.getIdLugar()));
                pw.println("APUTS obtenidos: +" + t.getCantidad());
                pw.println("--------------------------------------------");
            });

            // sugerencia de próximos pasos
            int faltantes = Math.max(0, APUTS_REQUERIDAS - u.getTotalAputs());
            pw.println("APUTS faltantes para graduación (96): " + faltantes);
            pw.println("============================================");

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Archivo creado: " + archivo);
    }

    // ===========================
    // RESTABLECER CONTRASEÑA
    // ===========================
    public boolean restablecerContrasena(String correo, String nueva) {
        Usuario u = buscarUsuarioPorCorreo(correo);
        if (u == null) return false;
        u.setContrasena(nueva);
        log("Contraseña restablecida para: " + u.getNombre() + " (ID " + u.getId() + ")");
        saveUsuarios();
        return true;
    }

    // ===========================
    // PERFIL RESUMEN
    // ===========================
    public String perfilResumen(int idUsuario) {
        Usuario u = buscarUsuarioPorId(idUsuario);
        if (u == null) return "Usuario no encontrado.";
        StringBuilder sb = new StringBuilder();
        sb.append("====== PERFIL ======\n");
        sb.append("ID: ").append(u.getId()).append("\n");
        sb.append("Nombre: ").append(u.getNombre()).append("\n");
        sb.append("Avatar: ").append(u.getAvatar()).append("\n");
        sb.append("APUTS: ").append(u.getTotalAputs()).append(" (").append(String.format("%.1f", porcentajeAvance(u))).append("%)\n");
        sb.append("Alertas alcanzadas: ").append(u.getHitosNotificados().isEmpty() ? "Ninguna" :
                u.getHitosNotificados().stream().sorted().map(String::valueOf).collect(Collectors.joining(", ")) + "%").append("\n");
        long lugaresVisitados = transacciones.stream().filter(t -> t.getIdUsuario() == idUsuario).map(TransaccionAPUTS::getIdLugar).distinct().count();
        sb.append("Lugares visitados: ").append(lugaresVisitados).append("\n");
        Optional<TransaccionAPUTS> ultima = transacciones.stream().filter(t -> t.getIdUsuario() == idUsuario).max(Comparator.comparing(TransaccionAPUTS::getFecha));
        sb.append("Última transacción: ").append(ultima.map(TransaccionAPUTS::getFecha).map(Object::toString).orElse("N/A")).append("\n");
        sb.append("====================");
        return sb.toString();
    
    }
}
