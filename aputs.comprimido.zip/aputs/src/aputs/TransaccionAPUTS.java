package aputs;

import java.time.LocalDateTime;

public class TransaccionAPUTS {
     private int id;
    private int idUsuario;
    private int idLugar;
    private int cantidad;
    private LocalDateTime fecha;

    public TransaccionAPUTS(int idUsuario, int idLugar, int cantidad) {
        this.id = IdGenerator.generarId();
        this.idUsuario = idUsuario;
        this.idLugar = idLugar;
        this.cantidad = cantidad;
        this.fecha = LocalDateTime.now();
    }

    public int getId() { return id; }
    public int getIdUsuario() { return idUsuario; }
    public int getIdLugar() { return idLugar; }
    public int getCantidad() { return cantidad; }
    public LocalDateTime getFecha() { return fecha; }
}
