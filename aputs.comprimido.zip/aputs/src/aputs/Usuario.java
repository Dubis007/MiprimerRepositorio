package aputs;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Usuario implements Serializable {
     private int id;
    private String nombre;
    private String correo;
    private String contrasena;
    private String avatar; // avatar ASCII seguro
    private int totalAputs;

    // Milestones notificados (50%, 75%, 90%)
    private Set<Integer> hitosNotificados = new HashSet<>();

    // ============================
    // CONSTRUCTOR
    // ============================
    public Usuario(String nombre, String correo, String contrasena) {
        this.id = IdGenerator.generarId();
        this.nombre = nombre;
        this.correo = correo;
        this.contrasena = contrasena;

        // Avatar por defecto
        this.avatar = "( ^ _ ^ )";

        this.totalAputs = 0;
    }

    // ============================
    // GETTERS
    // ============================
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }
    public String getContrasena() { return contrasena; }
    public String getAvatar() { return avatar; }
    public int getTotalAputs() { return totalAputs; }
    public Set<Integer> getHitosNotificados() { return hitosNotificados; }

    // ============================
    // SETTERS
    // ============================
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setCorreo(String correo) { this.correo = correo; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
    public void setAvatar(String avatar) { this.avatar = avatar; }

    // ============================
    // APUTS
    // ============================
    public void addAputs(int cantidad) {
        if (cantidad > 0) {
            this.totalAputs += cantidad;
        }
    }

    // ============================
    // ALERTAS
    // ============================
    public void marcarHitoNotificado(int porcentaje) {
        hitosNotificados.add(porcentaje);
    }

    public boolean yaNotificado(int porcentaje) {
        return hitosNotificados.contains(porcentaje);
    }
}
